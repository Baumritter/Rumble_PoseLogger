*Version 1.0.1*
- Readme File adjusted
*Version 1.0.0*
- Created
