1. Install MelonLoader
2. Run Game
3. Drop Folders into Rumble Folder
4. Play Game.

# Help And Other Resources
Get help and find other resources in the Modding Discord:
https://discord.gg/fsbcnZgzfa