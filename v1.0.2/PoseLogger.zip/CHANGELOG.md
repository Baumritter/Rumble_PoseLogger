*Version 1.0.2*
- Added Logging Output to File
- Added Settings File with the following Options:
	- Enable/Disable Log Output to Console
	- Enable/Disable Log Output to File
*Version 1.0.1*
- Readme File adjusted
*Version 1.0.0*
- Created
